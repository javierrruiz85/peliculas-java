/**
 *
 * Contiene el pojo de alerta. Lo situamos en su propio package porque no actua contra la BBDD 
 *
 * @author Javier Ruiz
 * @version 1.0
 * 
 */

package casa.mi.controller.pojo;