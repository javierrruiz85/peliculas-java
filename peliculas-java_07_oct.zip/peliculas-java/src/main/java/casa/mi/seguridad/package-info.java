/**
 *
 * Contiene los filtros de seguridad del proyecto. 
 *
 * @author Javier Ruiz
 * @version 1.0
 * 
 */

package casa.mi.seguridad;