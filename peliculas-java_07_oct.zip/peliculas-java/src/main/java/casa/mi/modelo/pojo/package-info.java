/**
 *
 * Contiene todos los pojos del proyecto 
 *
 * @author Javier Ruiz
 * @version 1.0
 * 
 */

package casa.mi.modelo.pojo;