/**
 *
 * Contiene todas las clases DAO del proyecto. En este proyecto estas realizan la funcion de un DaoImpl.  
 *
 * @author Javier Ruiz
 * @version 1.0
 * 
 */

package casa.mi.modelo.dao;