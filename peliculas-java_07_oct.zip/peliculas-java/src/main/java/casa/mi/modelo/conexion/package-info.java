/**
 *
 * Contiene la clase ConnectionManager, que se encarga del enviar a la BBDD el usuario y contraseña de esta 
 *
 * @author Javier Ruiz
 * @version 1.0
 * 
 */

package casa.mi.modelo.conexion;